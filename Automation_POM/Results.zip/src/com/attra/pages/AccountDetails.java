package com.attra.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.attra.driverscript.Driverscript;

public class AccountDetails extends Driverscript {
	
	public  WebDriver driver;
    public AccountDetails(WebDriver driver) {
	this.driver=driver;
	PageFactory.initElements(driver, this);
	}



@FindBy(xpath="//a[contains(.,'Business Unit')]/following::input[1]")
WebElement BusinessUnit;



public WebElement getBusinessUnit() {
	return BusinessUnit;
}



public WebElement getAccountNumber() {
	return AccountNumber;
}



public WebElement getProduct() {
	return Product;
}



public WebElement getBillingAcctInd() {
	return BillingAcctInd;
}



@FindBy(xpath="//a[contains(.,'Account Number')]/following::input[1]")
WebElement AccountNumber;



@FindBy(xpath="//a[contains(.,'Product(Required only for ADD)')]/following::input[1]")
WebElement Product;



@FindBy(xpath="//a[contains(.,'Billing Acct Ind(Req only for ADD)')]/following::input[1]")
WebElement BillingAcctInd;

}
