package com.attra.testcases;

import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import com.attra.datatable.Datatable;
import com.attra.driverscript.Driverscript;
import com.attra.pages.AccountDetails;
import com.attra.pages.LoginPage;

public class AccountDeatilsFetch extends Driverscript {
	
	@Test(enabled=true)
	public void fetchDetailsAccountDetails() {
		HashMap<String, String> dataHashMap;
		HashMap<String, String> dataOutputHashmap = null;
		dataHashMap=Datatable.getCellData(datasheet, "Sheet1", 1);
		if(dataHashMap.get("RunStatus").equalsIgnoreCase("Y")) {
		try{
		Driverscript.runner("Sheet1", 1, dataHashMap);
		driver.get(dataHashMap.get("Url"));
		initElements();
		//Thread.sleep(10000);
		loginPage.getUserName().sendKeys(dataHashMap.get("UserName"));
		loginPage.getPassword().sendKeys(dataHashMap.get("UserName"));
		loginPage.getSubmitButton().click();
		
		driver.findElement(By.id("searchTextBox")).sendKeys("account details");
	//	Thread.sleep(3000);
		driver.findElement(By.xpath("//span[@ng-bind-html=\"result.name\" and starts-with(.,'Account Detail')]")).click();
	//	Thread.sleep(5000);
		driver.findElement(By.xpath("//a[contains(.,'Business Unit')]/following::input[1]")).sendKeys("100");
		driver.findElement(By.xpath("//a[contains(.,'Account Number')]/following::input[1]")).sendKeys("0004200010000000355");
		driver.findElement(By.xpath("//a[contains(.,'Product(Required only for ADD)')]/following::input[1]")).sendKeys("1");
		driver.findElement(By.xpath("//a[contains(.,'Billing Acct Ind(Req only for ADD)')]/following::input[1]")).sendKeys("0");
		driver.findElement(By.xpath("//button[contains(.,'Query')]")).click();
		Thread.sleep(5000);
		
		dataOutputHashmap.put("Account Number", accountDetails.getAccountNumber().getText());
		dataOutputHashmap.put("BillingAcctInd", accountDetails.getBillingAcctInd().getText());
		dataOutputHashmap.put("product", accountDetails.getProduct().getText());
		Datatable.saveFetchedValuesToExcel("C:\\Temp\\testing.xlsx", "Sheet1", 1, 1, dataOutputHashmap);
		
		}
		catch(Exception e){
    	System.out.println(dataHashMap.get("TcName") +" test case failed");
    	e.printStackTrace();
    	driver.quit();
		}
			
		}
		else {
			
		}
				
	}
	
	
	public void initElements() {
		loginPage=new LoginPage(driver);				
		accountDetails=new AccountDetails(driver);
		
	}
	

}
