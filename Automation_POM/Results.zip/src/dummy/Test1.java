package dummy;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import com.attra.datatable.Datatable;

public class Test1 {
	
	public static void main(String[] args) {
		HashMap<String, String> test=	Datatable.getCellData("C:\\Temp\\test.xlsx", "Sheet1", 2);
		 for (Map.Entry<String,String> entry : test.entrySet())  
	            System.out.println("Key = " + entry.getKey() + 
	                             ", Value = " + entry.getValue()); 
	    } 
	
	}
 
	

